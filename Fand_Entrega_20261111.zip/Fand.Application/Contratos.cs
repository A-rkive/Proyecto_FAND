using System.ComponentModel.DataAnnotations;
namespace Fand.Application;

public sealed class FiltroListado
{
    [StringLength(100)] public string? Busqueda { get; set; }
    [Range(1, 3)] public int? Anio { get; set; }
    [Range(1, 3)] public int? AnioMax { get; set; }
    [Range(1, 1000000)] public int Pagina { get; set; } = 1;
    [Range(1, 100)] public int Tamano { get; set; } = 10;
}
public record Pagina<T>(IReadOnlyList<T> Items, int Total, int Numero, int Tamano)
{
    public int TotalPaginas => (int)Math.Ceiling((double)Total / Tamano);
}
public sealed class AlumnaEntrada
{
    [Required(ErrorMessage = "Ingresá el nombre."), StringLength(100)] public string Nombre { get; set; } = "";
    [Required(ErrorMessage = "Ingresá el apellido."), StringLength(100)] public string Apellido { get; set; } = "";
    [Required, EmailAddress(ErrorMessage = "Ingresá un email válido."), StringLength(254)] public string Email { get; set; } = "";
    [Required(ErrorMessage = "Ingresá el domicilio."), StringLength(250)] public string Domicilio { get; set; } = "";
    [Required, RegularExpression(@"^\d{7,9}$", ErrorMessage = "El DNI debe tener entre 7 y 9 dígitos, sin puntos.")] public string Dni { get; set; } = "";
    [Required, RegularExpression(@"^[0-9+() \-]{6,25}$", ErrorMessage = "Ingresá un teléfono válido, de 6 a 25 caracteres.")] public string Telefono { get; set; } = "";
    [Required, StringLength(30), RegularExpression(@"^[a-zA-Z0-9\-]+$", ErrorMessage = "El legajo admite letras, números y guiones.")] public string Legajo { get; set; } = "";
    [Range(1, 3)] public int Anio { get; set; } = 1;
}
public sealed class MateriaEntrada
{
    [Required(ErrorMessage = "Ingresá el nombre de la materia."), StringLength(150)] public string Nombre { get; set; } = "";
    [Range(1, 3)] public int Anio { get; set; } = 1;
}
public sealed class InscripcionEntrada
{
    [Range(1, int.MaxValue)] public int AlumnoId { get; set; }
    [Range(1, int.MaxValue)] public int MateriaId { get; set; }
}
public sealed class LoginEntrada
{
    [Required, EmailAddress, StringLength(254)] public string Email { get; set; } = "";
    [Required, StringLength(256)] public string Password { get; set; } = "";
}
public record InscripcionDto(int Id, int MateriaId, string Materia, int Anio, DateTime Fecha);
public record AlumnaDto(int Id, string Nombre, string Apellido, string Email, string Domicilio,
    string? Dni, string Telefono, string Legajo, int Anio, IReadOnlyList<InscripcionDto> Inscripciones);
public record MateriaDto(int Id, string Nombre, int Anio, int CantidadAlumnas);
public record ResumenDto(int Alumnas, int Materias, int Inscripciones, IReadOnlyList<CursoDto> Cursos);
public record CursoDto(int Anio, int Alumnas, int Materias);
public record SesionDto(string Token, DateTime Expira, string Email, string Rol);
public sealed class NoEncontradoException(string mensaje) : System.Exception(mensaje);
public sealed class ConflictoException(string mensaje) : System.Exception(mensaje);
public sealed class CredencialesException() : System.Exception("Email o contraseña incorrectos.");
public sealed class AccesoDenegadoException() : System.Exception("Esta cuenta no tiene acceso a la administración.");

