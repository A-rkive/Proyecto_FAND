using Fand.Domain;
namespace Fand.Application;

public sealed class AuthService(IUsuarioRepository usuarios, IClaves claves, ITokenService tokens)
{
    public async Task<SesionDto> LoginAsync(LoginEntrada entrada, CancellationToken ct)
    {
        var usuario = await usuarios.PorEmailAsync(entrada.Email.Trim().ToLowerInvariant(), ct);
        if (usuario is null || !claves.Verificar(usuario, entrada.Password))
            throw new CredencialesException();
        if (usuario.Rol != Roles.Admin)
            throw new AccesoDenegadoException();
        await usuarios.GuardarAsync(ct);
        return tokens.Crear(usuario);
    }
}

