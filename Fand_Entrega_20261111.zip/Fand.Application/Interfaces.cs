using Fand.Domain;
namespace Fand.Application;

public interface IAcademiaRepository
{
    Task<Pagina<AlumnaDto>> ListarAlumnasAsync(FiltroListado filtro, CancellationToken ct);
    Task<Alumno?> AlumnaAsync(int id, CancellationToken ct);
    Task<bool> IdentificacionEnUsoAsync(string dni, string legajo, int excluirId, CancellationToken ct);
    void Agregar(Alumno alumna);
    void Eliminar(Alumno alumna);
    Task<Pagina<MateriaDto>> ListarMateriasAsync(FiltroListado filtro, CancellationToken ct);
    Task<Materia?> MateriaAsync(int id, CancellationToken ct);
    Task<bool> MateriaRepetidaAsync(string nombre, int anio, int excluirId, CancellationToken ct);
    void Agregar(Materia materia);
    void Eliminar(Materia materia);
    Task<Inscripcion?> InscripcionAsync(int id, CancellationToken ct);
    void Agregar(Inscripcion inscripcion);
    void Eliminar(Inscripcion inscripcion);
    Task GuardarAsync(CancellationToken ct);
    Task<ResumenDto> ResumenAsync(CancellationToken ct);
}
public interface IUsuarioRepository
{
    Task<Usuario?> PorEmailAsync(string email, CancellationToken ct);
    Task GuardarAsync(CancellationToken ct);
}
public interface IClaves
{
    bool Verificar(Usuario usuario, string password);
}
public interface ITokenService
{
    SesionDto Crear(Usuario usuario);
}

