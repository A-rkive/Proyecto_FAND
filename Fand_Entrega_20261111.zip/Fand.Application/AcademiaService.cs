using Fand.Domain;
namespace Fand.Application;

// Los casos de uso dependen de contratos: no conocen SQL Server ni HttpContext.
public sealed class AcademiaService(IAcademiaRepository repo)
{
    public Task<Pagina<AlumnaDto>> ListarAlumnasAsync(FiltroListado f, CancellationToken ct) => repo.ListarAlumnasAsync(f, ct);
    public Task<Pagina<MateriaDto>> ListarMateriasAsync(FiltroListado f, CancellationToken ct) => repo.ListarMateriasAsync(f, ct);
    public Task<ResumenDto> ResumenAsync(CancellationToken ct) => repo.ResumenAsync(ct);
    public async Task<AlumnaDto> AlumnaAsync(int id, CancellationToken ct) =>
        Mapear(await repo.AlumnaAsync(id, ct) ?? throw new NoEncontradoException("No se encontró la alumna."));

    public async Task<AlumnaDto> CrearAlumnaAsync(AlumnaEntrada datos, CancellationToken ct)
    {
        ReglasAcademicas.ValidarAnio(datos.Anio);
        if (await repo.IdentificacionEnUsoAsync(datos.Dni.Trim(), datos.Legajo.Trim().ToUpperInvariant(), 0, ct))
            throw new ConflictoException("Ya existe una alumna con ese DNI o legajo.");
        var alumna = new Alumno();
        Aplicar(alumna, datos);
        repo.Agregar(alumna);
        await repo.GuardarAsync(ct);
        return Mapear(alumna);
    }
    public async Task EditarAlumnaAsync(int id, AlumnaEntrada datos, CancellationToken ct)
    {
        var alumna = await repo.AlumnaAsync(id, ct) ?? throw new NoEncontradoException("No se encontró la alumna.");
        ReglasAcademicas.ValidarAnio(datos.Anio);
        if (alumna.Inscripciones.Any(i => i.Materia.Anio > datos.Anio))
            throw new ConflictoException("Antes de cambiar el año, retirala de las materias que quedarían por encima de su cursada.");
        if (await repo.IdentificacionEnUsoAsync(datos.Dni.Trim(), datos.Legajo.Trim().ToUpperInvariant(), id, ct))
            throw new ConflictoException("Ya existe otra alumna con ese DNI o legajo.");
        Aplicar(alumna, datos);
        await repo.GuardarAsync(ct);
    }
    public async Task EliminarAlumnaAsync(int id, CancellationToken ct)
    {
        var alumna = await repo.AlumnaAsync(id, ct) ?? throw new NoEncontradoException("No se encontró la alumna.");
        if (alumna.Inscripciones.Count > 0)
            throw new ConflictoException("Primero cancelá sus inscripciones para poder eliminar la ficha.");
        repo.Eliminar(alumna);
        await repo.GuardarAsync(ct);
    }
    public async Task<MateriaDto> CrearMateriaAsync(MateriaEntrada datos, CancellationToken ct)
    {
        ReglasAcademicas.ValidarAnio(datos.Anio);
        var nombre = datos.Nombre.Trim();
        if (await repo.MateriaRepetidaAsync(nombre, datos.Anio, 0, ct))
            throw new ConflictoException("Ya existe una materia con ese nombre en el año seleccionado.");
        var materia = new Materia { Nombre = nombre, Anio = datos.Anio };
        repo.Agregar(materia);
        await repo.GuardarAsync(ct);
        return new(materia.Id, materia.Nombre, materia.Anio, 0);
    }
    public async Task<MateriaDto> MateriaAsync(int id, CancellationToken ct)
    {
        var materia = await repo.MateriaAsync(id, ct) ?? throw new NoEncontradoException("No se encontró la materia.");
        return new(materia.Id, materia.Nombre, materia.Anio, materia.Inscripciones.Count);
    }
    public async Task EditarMateriaAsync(int id, MateriaEntrada datos, CancellationToken ct)
    {
        var materia = await repo.MateriaAsync(id, ct) ?? throw new NoEncontradoException("No se encontró la materia.");
        ReglasAcademicas.ValidarAnio(datos.Anio);
        if (materia.Inscripciones.Any(i => i.Alumno.Anio < datos.Anio))
            throw new ConflictoException("Hay alumnas inscriptas cuyo año no permite cursar esta materia en el nuevo año.");
        if (await repo.MateriaRepetidaAsync(datos.Nombre.Trim(), datos.Anio, id, ct))
            throw new ConflictoException("Ya existe otra materia con ese nombre en el año seleccionado.");
        materia.Nombre = datos.Nombre.Trim();
        materia.Anio = datos.Anio;
        await repo.GuardarAsync(ct);
    }
    public async Task EliminarMateriaAsync(int id, CancellationToken ct)
    {
        var materia = await repo.MateriaAsync(id, ct) ?? throw new NoEncontradoException("No se encontró la materia.");
        if (materia.Inscripciones.Count > 0)
            throw new ConflictoException("No se puede eliminar esta materia porque tiene alumnas inscriptas.");
        repo.Eliminar(materia);
        await repo.GuardarAsync(ct);
    }
    public async Task<InscripcionDto> InscribirAsync(InscripcionEntrada datos, CancellationToken ct)
    {
        var alumna = await repo.AlumnaAsync(datos.AlumnoId, ct) ?? throw new NoEncontradoException("No se encontró la alumna.");
        var materia = await repo.MateriaAsync(datos.MateriaId, ct) ?? throw new NoEncontradoException("No se encontró la materia.");
        ReglasAcademicas.ValidarInscripcion(alumna.Anio, materia.Anio);
        if (alumna.Inscripciones.Any(i => i.MateriaId == materia.Id))
            throw new ConflictoException("La alumna ya está inscripta en esta materia.");
        var inscripcion = new Inscripcion { AlumnoId = alumna.Id, MateriaId = materia.Id };
        repo.Agregar(inscripcion);
        await repo.GuardarAsync(ct);
        return new(inscripcion.Id, materia.Id, materia.Nombre, materia.Anio, inscripcion.Fecha);
    }
    public async Task CancelarInscripcionAsync(int id, CancellationToken ct)
    {
        var inscripcion = await repo.InscripcionAsync(id, ct) ?? throw new NoEncontradoException("No se encontró la inscripción.");
        repo.Eliminar(inscripcion);
        await repo.GuardarAsync(ct);
    }
    private static void Aplicar(Alumno a, AlumnaEntrada d)
    {
        a.Nombre = d.Nombre.Trim(); a.Apellido = d.Apellido.Trim();
        a.Email = d.Email.Trim().ToLowerInvariant(); a.Dni = d.Dni.Trim();
        a.Domicilio = d.Domicilio.Trim(); a.Telefono = d.Telefono.Trim();
        a.Legajo = d.Legajo.Trim().ToUpperInvariant(); a.Anio = d.Anio;
    }
    public static AlumnaDto Mapear(Alumno a) => new(a.Id, a.Nombre, a.Apellido, a.Email,
        a.Domicilio, a.Dni, a.Telefono, a.Legajo, a.Anio,
        a.Inscripciones.OrderBy(i => i.Materia.Anio).ThenBy(i => i.Materia.Nombre)
        .Select(i => new InscripcionDto(i.Id, i.MateriaId, i.Materia.Nombre, i.Materia.Anio, i.Fecha)).ToList());
}

