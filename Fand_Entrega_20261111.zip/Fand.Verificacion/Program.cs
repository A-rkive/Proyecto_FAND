using System.Diagnostics;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using CLASE_ORM.Middlewares;
using Fand.Application;
using Fand.Domain;
using Fand.Infrastructure.Data;
using Fand.Infrastructure.Security;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.IdentityModel.Tokens;

var root = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "../../../../"));
var options = new DbContextOptionsBuilder<AppDbContext>()
    .UseSqlServer(@"Server=.\SQLEXPRESS;Database=FandDb;Trusted_Connection=True;TrustServerCertificate=True;").Options;
await using var db = new AppDbContext(options);
var uiEmail = "verificacion.ui@fand.test";
const string uiPassword = "Solo-Prueba-Temporal-Fand-2026!";
if (args.Contains("--preparar-ui"))
{
    if (!await db.Usuarios.AnyAsync(u => u.Email == uiEmail))
    {
        var u = new Usuario { Email = uiEmail, Rol = Roles.Admin };
        u.PasswordHash = new PasswordHasher<Usuario>().HashPassword(u, uiPassword);
        db.Usuarios.Add(u); await db.SaveChangesAsync();
    }
    Console.WriteLine("Cuenta temporal de verificación UI preparada.");
    return;
}
if (args.Contains("--limpiar-ui"))
{
    var u = await db.Usuarios.SingleOrDefaultAsync(u => u.Email == uiEmail);
    if (u != null) { db.Usuarios.Remove(u); await db.SaveChangesAsync(); }
    // Solo registros ficticios identificados expresamente por esta prueba.
    var alumnasUi = await db.Alumnos.Where(a => a.Legajo == "QA-UI-2026").ToListAsync();
    foreach (var a in alumnasUi)
    {
        var ins = await db.Inscripciones.Where(i => i.AlumnoId == a.Id).ToListAsync();
        db.Inscripciones.RemoveRange(ins); db.Alumnos.Remove(a);
    }
    var materiasUi = await db.Materias.Where(m => m.Nombre == "Botánica · prueba de interfaz").ToListAsync();
    foreach (var m in materiasUi)
        if (!await db.Inscripciones.AnyAsync(i => i.MateriaId == m.Id)) db.Materias.Remove(m);
    await db.SaveChangesAsync();
    Console.WriteLine("Cuenta y registros temporales de UI eliminados; datos previos conservados.");
    return;
}
var key = Convert.ToBase64String(RandomNumberGenerator.GetBytes(64));
var tag = "QA" + Guid.NewGuid().ToString("N")[..8];
var password = Convert.ToBase64String(RandomNumberGenerator.GetBytes(32));
var usuario = new Usuario { Email = tag.ToLowerInvariant() + "@fand.test", Rol = Roles.Admin };
usuario.PasswordHash = new PasswordHasher<Usuario>().HashPassword(usuario, password);
db.Usuarios.Add(usuario); await db.SaveChangesAsync();
var alumnosIds = new List<int>(); var materiasIds = new List<int>();
var antesMaterias = await db.Materias.AsNoTracking().ToDictionaryAsync(m => m.Id, m => m.Nombre);
var assertions = 0;
Process? servidor = null;
try
{
    var start = new ProcessStartInfo("dotnet")
    {
        WorkingDirectory = Path.Combine(root, "CLASE_ORM"), UseShellExecute = false,
        RedirectStandardOutput = true, RedirectStandardError = true, CreateNoWindow = true
    };
    start.ArgumentList.Add(Path.Combine(root, "CLASE_ORM/bin/Debug/net8.0/CLASE_ORM.dll"));
    start.ArgumentList.Add("--urls"); start.ArgumentList.Add("http://127.0.0.1:5212");
    start.Environment["ASPNETCORE_ENVIRONMENT"] = "Development";
    start.Environment["Jwt__Key"] = key;
    start.Environment["Database__MigrateOnStartup"] = "false";
    start.Environment["Logging__LogLevel__Default"] = "Warning";
    servidor = Process.Start(start) ?? throw new System.Exception("No se pudo iniciar el servidor de prueba.");
    servidor.OutputDataReceived += (_, _) => { };
    servidor.ErrorDataReceived += (_, _) => { };
    servidor.BeginOutputReadLine(); servidor.BeginErrorReadLine();
    using var http = new HttpClient { BaseAddress = new Uri("http://127.0.0.1:5212"), Timeout = TimeSpan.FromSeconds(15) };
    for (var i = 0; i < 30; i++)
    {
        try { if ((await http.GetAsync("/api/health")).IsSuccessStatusCode) break; } catch (HttpRequestException) { }
        await Task.Delay(200);
    }
    async Task<JsonElement> Request(HttpMethod method, string url, object? data, int esperado)
    {
        using var request = new HttpRequestMessage(method, url);
        if (data != null) request.Content = JsonContent.Create(data);
        using var response = await http.SendAsync(request);
        var body = await response.Content.ReadAsStringAsync();
        Assert((int)response.StatusCode == esperado, $"{method} {url.Split('?')[0]} → {esperado} (recibido {(int)response.StatusCode})");
        if (body.Length == 0) return default;
        var json = JsonDocument.Parse(body).RootElement.Clone();
        if (esperado >= 400)
        {
            Assert(json.TryGetProperty("detail", out _), "Error con detail descriptivo");
            Assert(json.TryGetProperty("status", out var status) && status.GetInt32() == esperado, "Status coherente en el body");
        }
        return json;
    }
    void Assert(bool condicion, string mensaje)
    {
        if (!condicion) throw new System.Exception("FALLÓ: " + mensaje);
        assertions++; Console.WriteLine("OK " + mensaje);
    }
    await Request(HttpMethod.Get, "/api/Alumno", null, 401);
    await Request(HttpMethod.Get, "/api/Materia", null, 401);
    await Request(HttpMethod.Get, "/api/Resumen", null, 401);
    await Request(HttpMethod.Post, "/api/Auth/login", new { email = usuario.Email, password = "incorrecta" }, 401);
    var login = await Request(HttpMethod.Post, "/api/Auth/login", new { email = usuario.Email, password }, 200);
    Assert(login.GetProperty("rol").GetString() == Roles.Admin, "Login devuelve rol Admin");
    Assert(!login.TryGetProperty("passwordHash", out _), "Login no expone hash de contraseña");
    var token = login.GetProperty("token").GetString()!;
    http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
    await Request(HttpMethod.Get, "/api/Auth/me", null, 200);
    var roleToken = new TokenService(new JwtSettings(key)).Crear(new Usuario { Id = 0, Email = "sin.permiso@fand.test", Rol = "Alumna" });
    http.DefaultRequestHeaders.Authorization = new("Bearer", roleToken.Token);
    await Request(HttpMethod.Get, "/api/Alumno", null, 403);
    await Request(HttpMethod.Post, "/api/Materia", new { nombre = tag, anio = 1 }, 403);
    var signing = new SigningCredentials(new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key)), SecurityAlgorithms.HmacSha256);
    var expired = new JwtSecurityToken("Fand.Api", "Fand.Angular", [new Claim("role", "Admin")],
        DateTime.UtcNow.AddHours(-2), DateTime.UtcNow.AddHours(-1), signing);
    http.DefaultRequestHeaders.Authorization = new("Bearer", new JwtSecurityTokenHandler().WriteToken(expired));
    await Request(HttpMethod.Get, "/api/Alumno", null, 401);
    var fakeToken = new TokenService(new JwtSettings(Convert.ToBase64String(RandomNumberGenerator.GetBytes(64)))).Crear(usuario);
    http.DefaultRequestHeaders.Authorization = new("Bearer", fakeToken.Token);
    await Request(HttpMethod.Get, "/api/Alumno", null, 401);
    http.DefaultRequestHeaders.Authorization = new("Bearer", token);
    await Request(HttpMethod.Get, "/api/Alumno?pagina=0", null, 400);
    await Request(HttpMethod.Get, "/api/Alumno?anio=4", null, 400);
    await Request(HttpMethod.Post, "/api/Materia", new { nombre = " ", anio = 1 }, 400);
    var m1 = await Request(HttpMethod.Post, "/api/Materia", new { nombre = tag + " Primero", anio = 1 }, 201);
    var idM1 = m1.GetProperty("id").GetInt32(); materiasIds.Add(idM1);
    var m3 = await Request(HttpMethod.Post, "/api/Materia", new { nombre = tag + " Tercero", anio = 3 }, 201);
    var idM3 = m3.GetProperty("id").GetInt32(); materiasIds.Add(idM3);
    var baseDni = RandomNumberGenerator.GetInt32(800000000, 899999000);
    AlumnaEntrada Datos(int n, int anio) => new()
    {
        Nombre = tag, Apellido = "Prueba " + n, Email = $"alumna{n}@fand.test", Dni = (baseDni + n).ToString(),
        Domicilio = "Domicilio ficticio de verificación", Telefono = "1100000000", Legajo = tag + "-" + n, Anio = anio
    };
    var d1 = Datos(1, 1); var d3 = Datos(3, 3);
    var a1 = await Request(HttpMethod.Post, "/api/Alumno", d1, 201);
    var idA1 = a1.GetProperty("id").GetInt32(); alumnosIds.Add(idA1);
    var a3 = await Request(HttpMethod.Post, "/api/Alumno", d3, 201);
    var idA3 = a3.GetProperty("id").GetInt32(); alumnosIds.Add(idA3);
    await Request(HttpMethod.Post, "/api/Alumno", d1, 409);
    var pagina1 = await Request(HttpMethod.Get, "/api/Alumno?busqueda=" + tag + "&pagina=1&tamano=1", null, 200);
    var pagina2 = await Request(HttpMethod.Get, "/api/Alumno?busqueda=" + tag + "&pagina=2&tamano=1", null, 200);
    Assert(pagina1.GetProperty("total").GetInt32() == 2 && pagina1.GetProperty("items").GetArrayLength() == 1, "Total filtrado antes de paginar");
    Assert(pagina1.GetProperty("items")[0].GetProperty("id").GetInt32() != pagina2.GetProperty("items")[0].GetProperty("id").GetInt32(), "Páginas diferentes y orden estable");
    var filtro = await Request(HttpMethod.Get, "/api/Alumno?busqueda=" + tag + "&anio=3", null, 200);
    Assert(filtro.GetProperty("total").GetInt32() == 1, "Filtro combinado de texto y año");
    var opciones = await Request(HttpMethod.Get, "/api/Materia?busqueda=" + tag + "&anioMax=1", null, 200);
    Assert(opciones.GetProperty("total").GetInt32() == 1, "Selector respeta año máximo");
    await Request(HttpMethod.Post, "/api/Inscripciones", new { alumnoId = idA1, materiaId = idM3 }, 409);
    var i1 = await Request(HttpMethod.Post, "/api/Inscripciones", new { alumnoId = idA1, materiaId = idM1 }, 201);
    var i31 = await Request(HttpMethod.Post, "/api/Inscripciones", new { alumnoId = idA3, materiaId = idM1 }, 201);
    var i33 = await Request(HttpMethod.Post, "/api/Inscripciones", new { alumnoId = idA3, materiaId = idM3 }, 201);
    await Request(HttpMethod.Post, "/api/Inscripciones", new { alumnoId = idA3, materiaId = idM1 }, 409);
    await Request(HttpMethod.Delete, "/api/Materia/" + idM1, null, 409);
    await Request(HttpMethod.Delete, "/api/Alumno/" + idA1, null, 409);
    await Request(HttpMethod.Put, "/api/Materia/" + idM1, new { nombre = tag + " Primero", anio = 3 }, 409);
    d3.Anio = 1;
    await Request(HttpMethod.Put, "/api/Alumno/" + idA3, d3, 409);
    d3.Anio = 3; d3.Telefono = "1199999999";
    await Request(HttpMethod.Put, "/api/Alumno/" + idA3, d3, 204);
    var detalle = await Request(HttpMethod.Get, "/api/Alumno/" + idA3, null, 200);
    Assert(detalle.GetProperty("inscripciones").GetArrayLength() == 2, "Detalle con múltiples materias y sin ciclos JSON");
    Assert(detalle.GetProperty("telefono").GetString() == d3.Telefono, "Edición persistida");
    await Request(HttpMethod.Get, "/api/Alumno/2147483647", null, 404);
    foreach (var i in new[] { i1, i31, i33 })
        await Request(HttpMethod.Delete, "/api/Inscripciones/" + i.GetProperty("id").GetInt32(), null, 204);
    foreach (var id in alumnosIds) await Request(HttpMethod.Delete, "/api/Alumno/" + id, null, 204);
    await Request(HttpMethod.Put, "/api/Materia/" + idM1, new { nombre = tag + " Editada", anio = 2 }, 204);
    foreach (var id in materiasIds) await Request(HttpMethod.Delete, "/api/Materia/" + id, null, 204);
    await Request(HttpMethod.Get, "/api/Resumen", null, 200);
    for (var a = 1; a <= 3; a++)
    for (var m = 1; m <= 3; m++)
    {
        var permitido = true;
        try { ReglasAcademicas.ValidarInscripcion(a, m); } catch (ReglaNegocioException) { permitido = false; }
        Assert(permitido == (m <= a), $"Regla de años {a}/{m}");
    }
    var contexto = new DefaultHttpContext(); contexto.Response.Body = new MemoryStream();
    var middleware = new ErroresMiddleware(_ => throw new InvalidOperationException("DETALLE_INTERNO_NO_VISIBLE"), NullLogger<ErroresMiddleware>.Instance);
    await middleware.InvokeAsync(contexto);
    contexto.Response.Body.Position = 0;
    var error500 = await new StreamReader(contexto.Response.Body).ReadToEndAsync();
    Assert(contexto.Response.StatusCode == 500 && !error500.Contains("DETALLE_INTERNO_NO_VISIBLE") && error500.Contains("traceId"), "Middleware 500 estructurado sin detalles internos");
    Assert(!typeof(Alumno).Assembly.GetReferencedAssemblies().Any(a => a.Name!.Contains("EntityFramework") || a.Name.Contains("AspNetCore")), "Dominio independiente de EF y HTTP");
    Assert(!typeof(AcademiaService).Assembly.GetReferencedAssemblies().Any(a => a.Name!.Contains("Infrastructure") || a.Name.Contains("EntityFramework")), "Application independiente de Infrastructure y EF");
    Console.WriteLine($"RESULTADO: {assertions} comprobaciones correctas.");
}
finally
{
    if (servidor != null && !servidor.HasExited) { servidor.Kill(entireProcessTree: true); await servidor.WaitForExitAsync(); }
    db.ChangeTracker.Clear();
    db.Inscripciones.RemoveRange(await db.Inscripciones.Where(i => alumnosIds.Contains(i.AlumnoId)).ToListAsync());
    await db.SaveChangesAsync();
    db.Alumnos.RemoveRange(await db.Alumnos.Where(a => alumnosIds.Contains(a.Id)).ToListAsync());
    db.Materias.RemoveRange(await db.Materias.Where(m => materiasIds.Contains(m.Id)).ToListAsync());
    db.Usuarios.RemoveRange(await db.Usuarios.Where(u => u.Id == usuario.Id).ToListAsync());
    await db.SaveChangesAsync();
    var despues = await db.Materias.AsNoTracking().ToDictionaryAsync(m => m.Id, m => m.Nombre);
    if (antesMaterias.Count != despues.Count || antesMaterias.Any(p => !despues.TryGetValue(p.Key, out var nombre) || nombre != p.Value))
        throw new System.Exception("La prueba detectó un cambio inesperado en materias anteriores.");
    Console.WriteLine("Datos temporales retirados; materias previas conservadas.");
}

