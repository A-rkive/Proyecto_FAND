@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Detener-Fand.ps1"
if errorlevel 1 pause

