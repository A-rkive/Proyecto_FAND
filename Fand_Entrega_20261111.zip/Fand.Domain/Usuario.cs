﻿namespace Fand.Domain
{
    public class Usuario // Esta clase describe los datos de una cuenta de acceso
    {   
    public int Id { get; set; }
    public string Email { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public string Rol { get; set; } = "Alumna"; //el rol predeterminado es alumna
    }
       
}

