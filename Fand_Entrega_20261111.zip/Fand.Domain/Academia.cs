namespace Fand.Domain;

public class Alumno
{
    public int Id { get; set; }
    public string Nombre { get; set; } = "";
    public string Apellido { get; set; } = "";
    public string Email { get; set; } = "";
    public string Domicilio { get; set; } = "";
    public string? Dni { get; set; }
    public string Telefono { get; set; } = "";
    public string Legajo { get; set; } = "";
    public int Anio { get; set; } = 1;
    public List<Inscripcion> Inscripciones { get; set; } = [];
}
public class Materia
{
    public int Id { get; set; }
    public string Nombre { get; set; } = "";
    public int Anio { get; set; } = 1;
    public List<Inscripcion> Inscripciones { get; set; } = [];
}
public class Profesor
{
    public int Id { get; set; }
    public string Nombre { get; set; } = "";
}
public class Inscripcion
{
    public int Id { get; set; }
    public int AlumnoId { get; set; }
    public Alumno Alumno { get; set; } = null!;
    public int MateriaId { get; set; }
    public Materia Materia { get; set; } = null!;
    public DateTime Fecha { get; set; } = DateTime.UtcNow;
}
public sealed class ReglaNegocioException(string mensaje) : System.Exception(mensaje);

public static class ReglasAcademicas
{
    public static void ValidarAnio(int anio)
    {
        if (anio is < 1 or > 3)
            throw new ReglaNegocioException("El año de cursada debe ser primero, segundo o tercero.");
    }
    public static void ValidarInscripcion(int anioAlumna, int anioMateria)
    {
        ValidarAnio(anioAlumna);
        ValidarAnio(anioMateria);
        if (anioMateria > anioAlumna)
            throw new ReglaNegocioException("La alumna solo puede inscribirse a materias de su año o de años anteriores.");
    }
}
public static class Roles
{
    public const string Admin = "Admin";
}

