import { inject, Injectable, signal } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { CanActivateFn, Router } from '@angular/router';
import { catchError, tap, throwError } from 'rxjs';
import { Sesion } from './models';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private http = inject(HttpClient);
  private router = inject(Router);
  readonly sesion = signal<Sesion | null>(this.recuperar());
  private recuperar(): Sesion | null {
    try {
      const value = JSON.parse(sessionStorage.getItem('fand.sesion') ?? 'null') as Sesion | null;
      return value?.rol === 'Admin' && Date.parse(value.expira) > Date.now() ? value : null;
    } catch { return null; }
  }
  vigente(): boolean {
    const s = this.sesion();
    return !!s && s.rol === 'Admin' && Date.parse(s.expira) > Date.now();
  }
  login(email: string, password: string) {
    return this.http.post<Sesion>('/api/Auth/login', { email, password }).pipe(tap(s => {
      this.sesion.set(s);
      sessionStorage.setItem('fand.sesion', JSON.stringify(s));
    }));
  }
  salir(vencida = false) {
    this.sesion.set(null);
    sessionStorage.removeItem('fand.sesion');
    void this.router.navigate(['/ingresar'], { queryParams: vencida ? { sesion: 'vencida' } : {} });
  }
}
export const adminGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  return auth.vigente() || inject(Router).createUrlTree(['/ingresar']);
};
export const authInterceptor: HttpInterceptorFn = (request, next) => {
  const auth = inject(AuthService);
  const s = auth.sesion();
  const propia = request.url.startsWith('/api/');
  if (propia && s && !request.url.endsWith('/Auth/login'))
    request = request.clone({ setHeaders: { Authorization: 'Bearer ' + s.token } });
  return next(request).pipe(catchError((error: HttpErrorResponse) => {
    if (propia && error.status === 401 && !request.url.endsWith('/Auth/login')) auth.salir(true);
    return throwError(() => error);
  }));
};
