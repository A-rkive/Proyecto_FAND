export interface Inscripcion { id: number; materiaId: number; materia: string; anio: number; fecha: string; }
export interface Alumna { id: number; nombre: string; apellido: string; email: string; domicilio: string; dni: string | null; telefono: string; legajo: string; anio: number; inscripciones: Inscripcion[]; }
export type AlumnaEntrada = Omit<Alumna, 'id' | 'inscripciones'>;
export interface Materia { id: number; nombre: string; anio: number; cantidadAlumnas: number; }
export interface Pagina<T> { items: T[]; total: number; numero: number; tamano: number; totalPaginas: number; }
export interface Curso { anio: number; alumnas: number; materias: number; }
export interface Resumen { alumnas: number; materias: number; inscripciones: number; cursos: Curso[]; }
export interface Sesion { token: string; expira: string; email: string; rol: string; }
export interface Filtro { busqueda?: string; anio?: number | null; anioMax?: number; pagina?: number; tamano?: number; }
export const ANIOS = [{ valor: 1, nombre: 'Primero' }, { valor: 2, nombre: 'Segundo' }, { valor: 3, nombre: 'Tercero' }];
export const nombreAnio = (anio: number) => ANIOS.find(a => a.valor === anio)?.nombre ?? 'Sin asignar';
export function mensajeError(error: any): string {
  if (error?.status === 0) return 'No pudimos conectar con el servidor. Comprobá que la API esté en ejecución.';
  const errors = error?.error?.errors;
  if (errors) return (Object.values(errors).flat() as string[]).join(' ');
  return error?.error?.detail ?? 'No se pudo completar la operación. Intentá nuevamente.';
}
