import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Alumna, AlumnaEntrada, Filtro, Inscripcion, Materia, Pagina, Resumen } from './models';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private http = inject(HttpClient);
  private params(f: Filtro) {
    let p = new HttpParams();
    for (const [key, value] of Object.entries(f)) if (value !== null && value !== undefined && value !== '') p = p.set(key, String(value));
    return p;
  }
  resumen() { return this.http.get<Resumen>('/api/Resumen'); }
  alumnas(f: Filtro) { return this.http.get<Pagina<Alumna>>('/api/Alumno', { params: this.params(f) }); }
  alumna(id: number) { return this.http.get<Alumna>('/api/Alumno/' + id); }
  guardarAlumna(datos: AlumnaEntrada, id?: number): Observable<Alumna | void> {
    return id ? this.http.put<void>('/api/Alumno/' + id, datos) : this.http.post<Alumna>('/api/Alumno', datos);
  }
  eliminarAlumna(id: number) { return this.http.delete<void>('/api/Alumno/' + id); }
  materias(f: Filtro) { return this.http.get<Pagina<Materia>>('/api/Materia', { params: this.params(f) }); }
  guardarMateria(datos: { nombre: string; anio: number }, id?: number): Observable<Materia | void> {
    return id ? this.http.put<void>('/api/Materia/' + id, datos) : this.http.post<Materia>('/api/Materia', datos);
  }
  eliminarMateria(id: number) { return this.http.delete<void>('/api/Materia/' + id); }
  inscribir(alumnoId: number, materiaId: number) { return this.http.post<Inscripcion>('/api/Inscripciones', { alumnoId, materiaId }); }
  cancelarInscripcion(id: number) { return this.http.delete<void>('/api/Inscripciones/' + id); }
}
