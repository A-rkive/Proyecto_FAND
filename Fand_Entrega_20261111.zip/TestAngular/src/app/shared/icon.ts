import { Component, Input } from '@angular/core';
@Component({
  selector: 'f-icon', standalone: true,
  template: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path [attr.d]="paths[name] || paths[\'leaf\']" /></svg>',
  styles: [':host{display:inline-flex;width:22px;height:22px;flex-shrink:0;align-items:center;justify-content:center}svg{width:100%;height:100%}']
})
export class Icon {
  @Input() name = 'leaf';
  paths: Record<string, string> = {
    leaf: 'M19 3C9 2 3 7 5 14c2 6 11 6 14-11ZM4 21 15 10M8 17l-1-6m5 2 5 1',
    grid: 'M3 3h7v7H3ZM14 3h7v7h-7ZM3 14h7v7H3ZM14 14h7v7h-7Z',
    students: 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75',
    book: 'M12 6C8 3 5 3 2 4v15c4-1 7 0 10 2m0-15c4-3 7-3 10-2v15c-4-1-7 0-10 2Zm0 0v15',
    logout: 'M9 21H4V3h5M14 8l5 4-5 4m-7-4h12',
    arrow: 'M4 12h16m-6-6 6 6-6 6',
    plus: 'M12 5v14M5 12h14',
    search: 'M10.5 18a7.5 7.5 0 1 0 0-15 7.5 7.5 0 0 0 0 15ZM16 16l5 5',
    edit: 'm15 5 4 4M4 20l5-1L21 7a2.8 2.8 0 0 0-4-4L5 15ZM13 20h8',
    trash: 'M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7m4-7v7',
    close: 'm6 6 12 12M18 6 6 18',
    check: 'm5 12 4 4L19 6',
    sparkles: 'm12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5ZM20 2v4m-2-2h4',
    lock: 'M5 10h14v11H5ZM8 10V6a4 4 0 0 1 8 0v4m-4 5v2',
    mail: 'M3 5h18v14H3ZM3 5l9 8 9-8',
    eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12Zm10 3a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z',
    back: 'M20 12H4m6-6-6 6 6 6'
  };
}
