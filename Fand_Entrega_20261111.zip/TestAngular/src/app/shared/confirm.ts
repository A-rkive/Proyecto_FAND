import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { Icon } from './icon';
@Component({ selector: 'app-confirm', standalone: true, imports: [MatDialogModule, MatButtonModule, Icon], template: '<div class="confirm-dialog"><span class="confirm-icon"><f-icon name="leaf"/></span><h2 mat-dialog-title>{{ data.titulo }}</h2><mat-dialog-content><p>{{ data.mensaje }}</p></mat-dialog-content><mat-dialog-actions align="end"><button mat-button (click)="ref.close(false)">Volver</button><button mat-flat-button class="danger-button" (click)="ref.close(true)">{{ data.boton || "Eliminar" }}</button></mat-dialog-actions></div>' })
export class ConfirmDialog { data = inject<{ titulo: string; mensaje: string; boton?: string }>(MAT_DIALOG_DATA); ref = inject(MatDialogRef<ConfirmDialog>); }
