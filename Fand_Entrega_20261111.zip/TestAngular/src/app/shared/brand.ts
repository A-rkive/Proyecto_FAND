import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
@Component({ selector: 'f-brand', standalone: true, imports: [RouterLink], template: '<a routerLink="/" class="brand" aria-label="Instituto Fand, inicio"><span class="brand-symbol"><img src="/logo-fand.png" alt="" width="50" height="70"></span><span><strong>Fand<span class="brand-dot">.</span></strong><small>INSTITUTO</small></span></a>' })
export class Brand {}
