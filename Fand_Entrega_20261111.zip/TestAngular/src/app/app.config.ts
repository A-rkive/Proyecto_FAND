import { ApplicationConfig, LOCALE_ID, provideBrowserGlobalErrorListeners, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { registerLocaleData } from '@angular/common';
import localeEs from '@angular/common/locales/es-AR';
import { MatPaginatorIntl } from '@angular/material/paginator';
import { routes } from './app.routes';
import { authInterceptor } from './core/auth';

registerLocaleData(localeEs);
function paginador(): MatPaginatorIntl {
  const p = new MatPaginatorIntl();
  p.itemsPerPageLabel = 'Por página';
  p.nextPageLabel = 'Página siguiente'; p.previousPageLabel = 'Página anterior';
  p.firstPageLabel = 'Primera página'; p.lastPageLabel = 'Última página';
  p.getRangeLabel = (page, size, total) => total ? (page * size + 1) + '–' + Math.min((page + 1) * size, total) + ' de ' + total : '0 registros';
  return p;
}
export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(), provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes), provideHttpClient(withInterceptors([authInterceptor])),
    { provide: LOCALE_ID, useValue: 'es-AR' }, { provide: MatPaginatorIntl, useFactory: paginador }
  ]
};
