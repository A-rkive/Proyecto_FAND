import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { finalize } from 'rxjs';
import { Materia, ANIOS, mensajeError } from '../core/models';
import { ApiService } from '../core/api';
import { Icon } from '../shared/icon';
@Component({ selector: 'app-materia-dialog', standalone: true, imports: [ReactiveFormsModule, MatDialogModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule, Icon], template: '<div class="dialog-heading"><div><p class="eyebrow">ESPACIOS PARA APRENDER</p><h2 mat-dialog-title>{{ data ? "Editar materia" : "Nueva materia" }}</h2></div><button mat-icon-button [disabled]="busy()" (click)="ref.close(false)" aria-label="Cerrar"><f-icon name="close"/></button></div><form [formGroup]="form" (ngSubmit)="guardar()"><mat-dialog-content>@if(error()){<div class="error-banner" role="alert">{{error()}}</div>}<mat-form-field appearance="outline"><mat-label>Nombre de la materia</mat-label><input matInput formControlName="nombre" maxlength="150"><mat-error>Ingresá el nombre de la materia.</mat-error></mat-form-field><mat-form-field appearance="outline"><mat-label>Año</mat-label><mat-select formControlName="anio">@for(a of anios; track a.valor){<mat-option [value]="a.valor">{{a.nombre}}</mat-option>}</mat-select></mat-form-field><p class="dialog-intro">Podrán cursarla las alumnas de este año y de años superiores.</p></mat-dialog-content><mat-dialog-actions align="end"><button mat-button type="button" [disabled]="busy()" (click)="ref.close(false)">Cancelar</button><button mat-flat-button type="submit" [disabled]="busy()">{{busy() ? "Guardando…" : "Guardar materia"}} <f-icon name="check"/></button></mat-dialog-actions></form>' })
export class MateriaDialog {
  data = inject<Materia | null>(MAT_DIALOG_DATA); ref = inject(MatDialogRef<MateriaDialog>);
  private fb = inject(FormBuilder); private api = inject(ApiService);
  anios = ANIOS; busy = signal(false); error = signal('');
  form = this.fb.nonNullable.group({ nombre: [this.data?.nombre ?? '', [Validators.required, Validators.maxLength(150)]], anio: [this.data?.anio ?? 1, [Validators.required, Validators.min(1), Validators.max(3)]] });
  guardar() {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.busy.set(true); this.error.set(''); this.ref.disableClose = true;
    this.api.guardarMateria(this.form.getRawValue(), this.data?.id).pipe(finalize(() => { this.busy.set(false); this.ref.disableClose = false; })).subscribe({
      next: () => this.ref.close(true), error: e => this.error.set(mensajeError(e))
    });
  }
}
