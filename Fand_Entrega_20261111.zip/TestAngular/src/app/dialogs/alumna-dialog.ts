import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { finalize } from 'rxjs';
import { Alumna, ANIOS, mensajeError } from '../core/models';
import { ApiService } from '../core/api';
import { Icon } from '../shared/icon';
@Component({ selector: 'app-alumna-dialog', standalone: true, imports: [ReactiveFormsModule, MatDialogModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule, Icon], templateUrl: './alumna-dialog.html' })
export class AlumnaDialog {
  data = inject<Alumna | null>(MAT_DIALOG_DATA); ref = inject(MatDialogRef<AlumnaDialog>);
  private fb = inject(FormBuilder); private api = inject(ApiService);
  anios = ANIOS; busy = signal(false); error = signal('');
  form = this.fb.nonNullable.group({
    nombre: [this.data?.nombre ?? '', [Validators.required, Validators.maxLength(100)]],
    apellido: [this.data?.apellido ?? '', [Validators.required, Validators.maxLength(100)]],
    email: [this.data?.email ?? '', [Validators.required, Validators.email, Validators.maxLength(254)]],
    dni: [this.data?.dni ?? '', [Validators.required, Validators.pattern(/^\d{7,9}$/)]],
    telefono: [this.data?.telefono ?? '', [Validators.required, Validators.pattern(/^[0-9+() \-]{6,25}$/)]],
    domicilio: [this.data?.domicilio ?? '', [Validators.required, Validators.maxLength(250)]],
    legajo: [this.data?.legajo ?? '', [Validators.required, Validators.maxLength(30), Validators.pattern(/^[a-zA-Z0-9\-]+$/)]],
    anio: [this.data?.anio ?? 1, [Validators.required, Validators.min(1), Validators.max(3)]]
  });
  guardar() {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.busy.set(true); this.error.set(''); this.ref.disableClose = true;
    this.api.guardarAlumna(this.form.getRawValue(), this.data?.id).pipe(finalize(() => { this.busy.set(false); this.ref.disableClose = false; })).subscribe({
      next: () => this.ref.close(true), error: e => this.error.set(mensajeError(e))
    });
  }
}
