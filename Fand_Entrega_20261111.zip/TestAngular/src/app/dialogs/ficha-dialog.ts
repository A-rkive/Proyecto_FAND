import { Component, DestroyRef, inject, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormsModule, FormControl, ReactiveFormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialog, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { debounceTime, distinctUntilChanged, finalize, Subject, startWith, switchMap, catchError, of } from 'rxjs';
import { Alumna, Materia, Inscripcion, mensajeError, nombreAnio } from '../core/models';
import { ApiService } from '../core/api';
import { Icon } from '../shared/icon';
import { ConfirmDialog } from '../shared/confirm';
@Component({ selector: 'app-ficha-dialog', standalone: true, imports: [DatePipe, FormsModule, ReactiveFormsModule, MatDialogModule, MatFormFieldModule, MatSelectModule, MatInputModule, MatButtonModule, MatProgressBarModule, Icon], templateUrl: './ficha-dialog.html' })
export class FichaDialog {
  data = inject<Alumna>(MAT_DIALOG_DATA); ref = inject(MatDialogRef<FichaDialog>);
  private api = inject(ApiService); private dialogs = inject(MatDialog); private destroyRef = inject(DestroyRef);
  alumna = signal(this.data); materias = signal<Materia[]>([]); busy = signal(false); error = signal(''); aviso = signal('');
  materiaId: number | null = null; buscar = new FormControl('', { nonNullable: true }); nombreAnio = nombreAnio;
  totalOpciones = signal(0); private recargar = new Subject<void>();
  constructor() {
    this.buscar.valueChanges.pipe(debounceTime(300), distinctUntilChanged(), takeUntilDestroyed()).subscribe(() => this.recargar.next());
    this.recargar.pipe(startWith(undefined), switchMap(() => this.api.materias({ busqueda: this.buscar.value, anioMax: this.alumna().anio, tamano: 100 }).pipe(catchError(e => { this.error.set(mensajeError(e)); return of(null); }))), takeUntilDestroyed()).subscribe(r => {
      if (r) { this.materias.set(r.items.filter(m => !this.alumna().inscripciones.some(i => i.materiaId === m.id))); this.totalOpciones.set(r.total); }
    });
  }
  actualizar() {
    this.api.alumna(this.data.id).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({ next: a => { this.alumna.set(a); this.recargar.next(); }, error: e => this.error.set(mensajeError(e)) });
  }
  inscribir() {
    if (!this.materiaId || this.busy()) return;
    this.busy.set(true); this.error.set(''); this.aviso.set('');
    this.api.inscribir(this.data.id, this.materiaId).pipe(finalize(() => this.busy.set(false))).subscribe({
      next: () => { this.materiaId = null; this.aviso.set('Inscripción realizada.'); this.actualizar(); }, error: e => this.error.set(mensajeError(e))
    });
  }
  cancelar(i: Inscripcion) {
    this.dialogs.open(ConfirmDialog, { width: '430px', data: { titulo: '¿Cancelar inscripción?', mensaje: 'Se retirará a ' + this.alumna().nombre + ' de ' + i.materia + '.', boton: 'Cancelar inscripción' } }).afterClosed().subscribe(ok => {
      if (!ok) return;
      this.busy.set(true); this.error.set(''); this.aviso.set('');
      this.api.cancelarInscripcion(i.id).pipe(finalize(() => this.busy.set(false))).subscribe({
        next: () => { this.aviso.set('Inscripción cancelada.'); this.actualizar(); }, error: e => this.error.set(mensajeError(e))
      });
    });
  }
}
