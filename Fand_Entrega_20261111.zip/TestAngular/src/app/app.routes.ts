import { Routes } from '@angular/router';
import { adminGuard } from './core/auth';
export const routes: Routes = [
  { path: '', loadComponent: () => import('./pages/home').then(m => m.HomePage), title: 'Instituto Fand · Aprender, crecer, florecer' },
  { path: 'ingresar', loadComponent: () => import('./pages/login').then(m => m.LoginPage), title: 'Ingresar · Fand' },
  { path: 'gestion', canActivate: [adminGuard], canActivateChild: [adminGuard], loadComponent: () => import('./pages/layout').then(m => m.AdminLayout), children: [
    { path: '', loadComponent: () => import('./pages/dashboard').then(m => m.DashboardPage), title: 'Vista general · Fand' },
    { path: 'alumnas', loadComponent: () => import('./pages/alumnas').then(m => m.AlumnasPage), title: 'Alumnas · Fand' },
    { path: 'materias', loadComponent: () => import('./pages/materias').then(m => m.MateriasPage), title: 'Materias · Fand' }
  ]},
  { path: 'dashboardA', redirectTo: 'gestion/alumnas', pathMatch: 'full' },
  { path: 'dashboardB', redirectTo: 'gestion/materias', pathMatch: 'full' },
  { path: '**', redirectTo: '' }
];