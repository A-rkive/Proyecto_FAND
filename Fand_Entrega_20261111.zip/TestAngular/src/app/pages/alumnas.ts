import { Component, DestroyRef, inject, signal } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Subject, debounceTime, distinctUntilChanged, startWith, switchMap, catchError, of, finalize } from 'rxjs';
import { ApiService } from '../core/api';
import { Alumna, ANIOS, mensajeError, nombreAnio } from '../core/models';
import { AlumnaDialog } from '../dialogs/alumna-dialog';
import { FichaDialog } from '../dialogs/ficha-dialog';
import { ConfirmDialog } from '../shared/confirm';
import { Icon } from '../shared/icon';
@Component({ selector: 'app-alumnas', standalone: true, imports: [FormsModule, ReactiveFormsModule, MatTableModule, MatPaginatorModule, MatDialogModule, MatButtonModule, MatInputModule, MatFormFieldModule, MatSelectModule, MatTooltipModule, MatProgressBarModule, MatSnackBarModule, Icon], templateUrl: './alumnas.html' })
export class AlumnasPage {
  private api = inject(ApiService); private dialogs = inject(MatDialog); private snack = inject(MatSnackBar);
  private route = inject(ActivatedRoute); private router = inject(Router); private destroyRef = inject(DestroyRef);
  readonly buscar = new FormControl('', { nonNullable: true }); readonly anios = ANIOS; readonly nombreAnio = nombreAnio;
  anio: number | null = null; pagina = 0; tamano = 10; total = signal(0); filas = signal<Alumna[]>([]); loading = signal(true); error = signal('');
  columnas = ['alumna', 'legajo', 'anio', 'materias', 'acciones']; private reload = new Subject<void>();
  constructor() {
    const anio = Number(this.route.snapshot.queryParamMap.get('anio')); this.anio = [1, 2, 3].includes(anio) ? anio : null;
    this.buscar.valueChanges.pipe(debounceTime(300), distinctUntilChanged(), takeUntilDestroyed()).subscribe(() => this.filtrar());
    this.reload.pipe(startWith(undefined), switchMap(() => {
      this.loading.set(true); this.error.set('');
      return this.api.alumnas({ busqueda: this.buscar.value, anio: this.anio, pagina: this.pagina + 1, tamano: this.tamano }).pipe(catchError(e => { this.error.set(mensajeError(e)); return of(null); }), finalize(() => this.loading.set(false)));
    }), takeUntilDestroyed()).subscribe(r => {
      if (!r) return;
      if (!r.items.length && this.pagina > 0) { this.pagina = Math.max(0, r.totalPaginas - 1); this.reload.next(); return; }
      this.filas.set(r.items); this.total.set(r.total);
    });
    if (this.route.snapshot.queryParamMap.has('nueva')) {
      this.editar();
      void this.router.navigate([], { relativeTo: this.route, queryParams: { nueva: null }, queryParamsHandling: 'merge', replaceUrl: true });
    }
  }
  cargar() { this.reload.next(); }
  filtrar() { this.pagina = 0; this.cargar(); }
  limpiar() { this.buscar.setValue('', { emitEvent: false }); this.anio = null; this.filtrar(); }
  cambiarPagina(e: PageEvent) { this.pagina = e.pageIndex; this.tamano = e.pageSize; this.cargar(); }
  editar(alumna?: Alumna) {
    this.dialogs.open(AlumnaDialog, { width: '680px', maxWidth: '95vw', data: alumna ?? null }).afterClosed().pipe(takeUntilDestroyed(this.destroyRef)).subscribe(ok => {
      if (ok) { this.snack.open('Ficha guardada.', 'Cerrar', { duration: 3500 }); this.cargar(); }
    });
  }
  ficha(alumna: Alumna) {
    this.dialogs.open(FichaDialog, { width: '740px', maxWidth: '95vw', data: alumna }).afterClosed().pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => this.cargar());
  }
  eliminar(alumna: Alumna) {
    this.dialogs.open(ConfirmDialog, { width: '430px', data: { titulo: '¿Eliminar esta ficha?', mensaje: 'Se eliminará la ficha de ' + alumna.nombre + ' ' + alumna.apellido + '. Si tiene inscripciones, primero deberás cancelarlas.' } }).afterClosed().pipe(takeUntilDestroyed(this.destroyRef)).subscribe(ok => {
      if (!ok) return;
      this.api.eliminarAlumna(alumna.id).subscribe({ next: () => { this.snack.open('Ficha eliminada.', 'Cerrar', { duration: 3500 }); this.cargar(); }, error: e => this.snack.open(mensajeError(e), 'Cerrar', { duration: 7000 }) });
    });
  }
}
