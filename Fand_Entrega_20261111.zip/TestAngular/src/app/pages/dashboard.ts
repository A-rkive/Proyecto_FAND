import { Component, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { ApiService } from '../core/api';
import { Resumen, mensajeError, nombreAnio } from '../core/models';
import { Icon } from '../shared/icon';
@Component({ selector: 'app-dashboard', standalone: true, imports: [RouterLink, MatButtonModule, MatProgressBarModule, Icon], templateUrl: './dashboard.html' })
export class DashboardPage {
  private api = inject(ApiService);
  resumen = signal<Resumen | null>(null); error = signal(''); nombreAnio = nombreAnio;
  constructor() { this.cargar(); }
  cargar() { this.error.set(''); this.api.resumen().subscribe({ next: r => this.resumen.set(r), error: e => this.error.set(mensajeError(e)) }); }
}
