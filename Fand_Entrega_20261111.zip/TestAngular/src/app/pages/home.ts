import { Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { Brand } from '../shared/brand';
import { Icon } from '../shared/icon';
import { AuthService } from '../core/auth';
@Component({ selector: 'app-home', standalone: true, imports: [RouterLink, MatButtonModule, Brand, Icon], templateUrl: './home.html' })
export class HomePage { auth = inject(AuthService); }
