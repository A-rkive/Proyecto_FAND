import { Component, inject, signal } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Router, RouterLink, ActivatedRoute } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { finalize } from 'rxjs';
import { AuthService } from '../core/auth';
import { mensajeError } from '../core/models';
import { Brand } from '../shared/brand';
import { Icon } from '../shared/icon';
@Component({ selector: 'app-login', standalone: true, imports: [ReactiveFormsModule, RouterLink, MatFormFieldModule, MatInputModule, MatButtonModule, MatProgressBarModule, Brand, Icon], templateUrl: './login.html' })
export class LoginPage {
  private fb = inject(FormBuilder); private auth = inject(AuthService); private router = inject(Router); private route = inject(ActivatedRoute);
  busy = signal(false); error = signal(''); mostrar = signal(false);
  vencida = this.route.snapshot.queryParamMap.get('sesion') === 'vencida';
  form = this.fb.nonNullable.group({ email: ['', [Validators.required, Validators.email]], password: ['', Validators.required] });
  constructor() { if (this.auth.vigente()) void this.router.navigate(['/gestion']); }
  ingresar() {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.busy.set(true); this.error.set('');
    const d = this.form.getRawValue();
    this.auth.login(d.email.trim(), d.password).pipe(finalize(() => this.busy.set(false))).subscribe({
      next: () => void this.router.navigate(['/gestion']), error: e => this.error.set(mensajeError(e))
    });
  }
}
