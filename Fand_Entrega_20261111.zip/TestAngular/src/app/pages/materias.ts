import { Component, DestroyRef, inject, signal } from '@angular/core';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Subject, debounceTime, distinctUntilChanged, startWith, switchMap, catchError, of, finalize } from 'rxjs';
import { ApiService } from '../core/api';
import { Materia, ANIOS, mensajeError, nombreAnio } from '../core/models';
import { MateriaDialog } from '../dialogs/materia-dialog';
import { ConfirmDialog } from '../shared/confirm';
import { Icon } from '../shared/icon';
@Component({ selector: 'app-materias', standalone: true, imports: [FormsModule, ReactiveFormsModule, MatTableModule, MatPaginatorModule, MatDialogModule, MatButtonModule, MatInputModule, MatFormFieldModule, MatSelectModule, MatTooltipModule, MatProgressBarModule, MatSnackBarModule, Icon], templateUrl: './materias.html' })
export class MateriasPage {
  private api = inject(ApiService); private dialogs = inject(MatDialog); private snack = inject(MatSnackBar); private destroyRef = inject(DestroyRef);
  buscar = new FormControl('', { nonNullable: true }); anios = ANIOS; nombreAnio = nombreAnio;
  anio: number | null = null; pagina = 0; tamano = 10; total = signal(0); filas = signal<Materia[]>([]); loading = signal(true); error = signal('');
  columnas = ['nombre', 'anio', 'alumnas', 'acciones']; private reload = new Subject<void>();
  constructor() {
    this.buscar.valueChanges.pipe(debounceTime(300), distinctUntilChanged(), takeUntilDestroyed()).subscribe(() => this.filtrar());
    this.reload.pipe(startWith(undefined), switchMap(() => {
      this.loading.set(true); this.error.set('');
      return this.api.materias({ busqueda: this.buscar.value, anio: this.anio, pagina: this.pagina + 1, tamano: this.tamano }).pipe(catchError(e => { this.error.set(mensajeError(e)); return of(null); }), finalize(() => this.loading.set(false)));
    }), takeUntilDestroyed()).subscribe(r => {
      if (!r) return;
      if (!r.items.length && this.pagina > 0) { this.pagina = Math.max(0, r.totalPaginas - 1); this.reload.next(); return; }
      this.filas.set(r.items); this.total.set(r.total);
    });
  }
  cargar() { this.reload.next(); }
  filtrar() { this.pagina = 0; this.cargar(); }
  limpiar() { this.buscar.setValue('', { emitEvent: false }); this.anio = null; this.filtrar(); }
  cambiarPagina(e: PageEvent) { this.pagina = e.pageIndex; this.tamano = e.pageSize; this.cargar(); }
  editar(materia?: Materia) {
    this.dialogs.open(MateriaDialog, { width: '480px', maxWidth: '95vw', data: materia ?? null }).afterClosed().pipe(takeUntilDestroyed(this.destroyRef)).subscribe(ok => {
      if (ok) { this.snack.open('Materia guardada.', 'Cerrar', { duration: 3500 }); this.cargar(); }
    });
  }
  eliminar(m: Materia) {
    this.dialogs.open(ConfirmDialog, { width: '430px', data: { titulo: '¿Eliminar esta materia?', mensaje: 'Se eliminará ' + m.nombre + '. La materia debe estar sin alumnas inscriptas.' } }).afterClosed().pipe(takeUntilDestroyed(this.destroyRef)).subscribe(ok => {
      if (!ok) return;
      this.api.eliminarMateria(m.id).subscribe({ next: () => { this.snack.open('Materia eliminada.', 'Cerrar', { duration: 3500 }); this.cargar(); }, error: e => this.snack.open(mensajeError(e), 'Cerrar', { duration: 7000 }) });
    });
  }
}
