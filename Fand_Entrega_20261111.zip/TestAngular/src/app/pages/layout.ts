import { Component, inject } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { DatePipe } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { AuthService } from '../core/auth';
import { Brand } from '../shared/brand';
import { Icon } from '../shared/icon';
@Component({ selector: 'app-layout', standalone: true, imports: [RouterLink, RouterLinkActive, RouterOutlet, DatePipe, MatButtonModule, Brand, Icon], templateUrl: './layout.html' })
export class AdminLayout { auth = inject(AuthService); hoy = new Date(); }
