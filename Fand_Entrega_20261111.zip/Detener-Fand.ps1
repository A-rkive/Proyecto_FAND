$ErrorActionPreference = 'Stop'
$fandState = Join-Path $PSScriptRoot '.runtime/procesos.json'
if (!(Test-Path -LiteralPath $fandState)) { Write-Host 'No hay procesos registrados por Iniciar-Fand.'; return }
$fandProcesses = Get-Content -LiteralPath $fandState -Raw | ConvertFrom-Json
foreach ($fandEntry in $fandProcesses) {
    $fandProcess = Get-Process -Id $fandEntry.Id -ErrorAction SilentlyContinue
    if ($fandProcess -and $fandProcess.StartTime.ToUniversalTime().ToString('O') -eq $fandEntry.Inicio) {
        & taskkill.exe /PID $fandProcess.Id /T /F | Out-Null
    }
}
Set-Content -LiteralPath $fandState -Value '[]' -Encoding UTF8
Write-Host 'Servicios iniciados por Iniciar-Fand detenidos.'

