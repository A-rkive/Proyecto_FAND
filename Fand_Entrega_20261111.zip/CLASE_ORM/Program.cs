using System.Security.Cryptography;
using System.Text;
using System.Threading.RateLimiting;
using CLASE_ORM.Middlewares;
using Fand.Application;
using Fand.Infrastructure.Data;
using Fand.Infrastructure.Security;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);
var conexion = builder.Configuration.GetConnectionString("Con")
    ?? throw new InvalidOperationException("Falta configurar ConnectionStrings:Con.");
if (new SqlConnectionStringBuilder(conexion).InitialCatalog != "FandDb")
    throw new InvalidOperationException("La conexión debe apuntar a FandDb.");

var key = builder.Configuration["Jwt:Key"];
if (string.IsNullOrWhiteSpace(key) && builder.Environment.IsDevelopment())
    key = Convert.ToBase64String(RandomNumberGenerator.GetBytes(64));
if (string.IsNullOrWhiteSpace(key) || Encoding.UTF8.GetByteCount(key) < 32)
    throw new InvalidOperationException("Configurá Jwt:Key con al menos 32 caracteres.");
var jwt = new JwtSettings(key);

builder.Services.AddSingleton(jwt);
builder.Services.AddDbContext<AppDbContext>(o => o.UseSqlServer(conexion));
builder.Services.AddScoped<IAcademiaRepository, AcademiaRepository>();
builder.Services.AddScoped<IUsuarioRepository, UsuarioRepository>();
builder.Services.AddScoped<IClaves, Claves>();
builder.Services.AddScoped<ITokenService, TokenService>();
builder.Services.AddScoped<AcademiaService>();
builder.Services.AddScoped<AuthService>();
builder.Services.AddControllers().ConfigureApiBehaviorOptions(o =>
{
    o.InvalidModelStateResponseFactory = context =>
    {
        var problem = new ValidationProblemDetails(context.ModelState)
        {
            Status = 400, Title = "Datos inválidos",
            Detail = "Revisá los campos indicados y volvé a intentar."
        };
        problem.Extensions["traceId"] = context.HttpContext.TraceIdentifier;
        return new BadRequestObjectResult(problem);
    };
});
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(o =>
{
    o.SwaggerDoc("v1", new OpenApiInfo { Title = "Instituto Fand · API", Version = "v1" });
    o.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    { Type = SecuritySchemeType.Http, Scheme = "bearer", BearerFormat = "JWT", Description = "Token del login de administración." });
    o.AddSecurityRequirement(new OpenApiSecurityRequirement
    { [new OpenApiSecurityScheme { Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" } }] = [] });
});
builder.Services.AddCors(o => o.AddPolicy("Angular", p =>
    p.WithOrigins("http://localhost:4200", "http://localhost:8080").AllowAnyHeader().AllowAnyMethod()));
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(o =>
{
    o.MapInboundClaims = false;
    o.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true, ValidIssuer = jwt.Issuer,
        ValidateAudience = true, ValidAudience = jwt.Audience,
        ValidateLifetime = true, ClockSkew = TimeSpan.FromSeconds(15),
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt.Key)),
        ValidAlgorithms = [SecurityAlgorithms.HmacSha256],
        NameClaimType = "email", RoleClaimType = "role"
    };
});
builder.Services.AddAuthorization(o =>
    o.FallbackPolicy = new AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build());
builder.Services.AddRateLimiter(o =>
{
    o.AddPolicy("login", context => RateLimitPartition.GetFixedWindowLimiter(
        context.Connection.RemoteIpAddress?.ToString() ?? "local",
        _ => new FixedWindowRateLimiterOptions { PermitLimit = 20, Window = TimeSpan.FromMinutes(1), QueueLimit = 0 }));
    o.OnRejected = async (context, ct) =>
    {
        context.HttpContext.Response.StatusCode = 429;
        await context.HttpContext.Response.WriteAsJsonAsync(new ProblemDetails
        { Status = 429, Title = "Demasiados intentos", Detail = "Esperá un minuto antes de intentar ingresar nuevamente." }, cancellationToken: ct);
    };
});

var app = builder.Build();
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
if (builder.Configuration.GetValue<bool?>("Database:MigrateOnStartup") ?? app.Environment.IsDevelopment())
{
    using var scope = app.Services.CreateScope();
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    await db.Database.MigrateAsync();
    await Inicializador.CrearAdminAsync(db, builder.Configuration);
}
app.UseCors("Angular");
app.UseMiddleware<ErroresMiddleware>();
app.UseStatusCodePages(async statusContext =>
{
    var response = statusContext.HttpContext.Response;
    var mensaje = response.StatusCode switch
    {
        401 => "Tu sesión no es válida o venció. Volvé a ingresar.",
        403 => "Tu cuenta no tiene permiso para realizar esta operación.",
        404 => "No se encontró el recurso solicitado.",
        _ => "No se pudo completar la solicitud."
    };
    await response.WriteAsJsonAsync(new ProblemDetails
    {
        Status = response.StatusCode, Title = "Solicitud rechazada", Detail = mensaje,
        Extensions = { ["traceId"] = statusContext.HttpContext.TraceIdentifier }
    });
});
app.UseRateLimiter();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.MapGet("/api/health", () => Results.Ok(new { status = "ok" })).AllowAnonymous();
app.Run();

public partial class Program { }
