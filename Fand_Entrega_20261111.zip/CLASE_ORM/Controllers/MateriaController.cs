using Fand.Application;
using Fand.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
namespace CLASE_ORM.Controllers;

[ApiController, Route("api/Materia"), Authorize(Roles = Roles.Admin)]
public class MateriaController(AcademiaService servicio) : ControllerBase
{
    [HttpGet] public Task<Pagina<MateriaDto>> Get([FromQuery] FiltroListado filtro, CancellationToken ct) => servicio.ListarMateriasAsync(filtro, ct);
    [HttpGet("{id:int}")] public Task<MateriaDto> Get(int id, CancellationToken ct) => servicio.MateriaAsync(id, ct);
    [HttpPost] public async Task<IActionResult> Post(MateriaEntrada datos, CancellationToken ct)
    {
        var materia = await servicio.CrearMateriaAsync(datos, ct);
        return CreatedAtAction(nameof(Get), new { id = materia.Id }, materia);
    }
    [HttpPut("{id:int}")] public async Task<IActionResult> Put(int id, MateriaEntrada datos, CancellationToken ct)
    { await servicio.EditarMateriaAsync(id, datos, ct); return NoContent(); }
    [HttpDelete("{id:int}")] public async Task<IActionResult> Delete(int id, CancellationToken ct)
    { await servicio.EliminarMateriaAsync(id, ct); return NoContent(); }
}
