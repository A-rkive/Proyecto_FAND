using Fand.Application;
using Fand.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
namespace CLASE_ORM.Controllers;

[ApiController, Route("api/Inscripciones"), Authorize(Roles = Roles.Admin)]
public class InscripcionesController(AcademiaService servicio) : ControllerBase
{
    [HttpPost] public async Task<IActionResult> Post(InscripcionEntrada datos, CancellationToken ct)
    { return StatusCode(201, await servicio.InscribirAsync(datos, ct)); }
    [HttpDelete("{id:int}")] public async Task<IActionResult> Delete(int id, CancellationToken ct)
    { await servicio.CancelarInscripcionAsync(id, ct); return NoContent(); }
}
[ApiController, Route("api/Resumen"), Authorize(Roles = Roles.Admin)]
public class ResumenController(AcademiaService servicio) : ControllerBase
{
    [HttpGet] public Task<ResumenDto> Get(CancellationToken ct) => servicio.ResumenAsync(ct);
}

