using Fand.Application;
using Fand.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
namespace CLASE_ORM.Controllers;

[ApiController, Route("api/Auth")]
public class AuthController(AuthService servicio) : ControllerBase
{
    [HttpPost("login"), AllowAnonymous, EnableRateLimiting("login")]
    public Task<SesionDto> Login(LoginEntrada entrada, CancellationToken ct) => servicio.LoginAsync(entrada, ct);

    [HttpGet("me"), Authorize(Roles = Roles.Admin)]
    public IActionResult Me() => Ok(new { email = User.FindFirst("email")?.Value, rol = User.FindFirst("role")?.Value });
}

