using Fand.Application;
using Fand.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
namespace CLASE_ORM.Controllers;

[ApiController, Route("api/Alumno"), Authorize(Roles = Roles.Admin)]
public class AlumnoController(AcademiaService servicio) : ControllerBase
{
    [HttpGet] public Task<Pagina<AlumnaDto>> Get([FromQuery] FiltroListado filtro, CancellationToken ct) => servicio.ListarAlumnasAsync(filtro, ct);
    [HttpGet("{id:int}")] public Task<AlumnaDto> Get(int id, CancellationToken ct) => servicio.AlumnaAsync(id, ct);
    [HttpPost] public async Task<IActionResult> Post(AlumnaEntrada datos, CancellationToken ct)
    {
        var alumna = await servicio.CrearAlumnaAsync(datos, ct);
        return CreatedAtAction(nameof(Get), new { id = alumna.Id }, alumna);
    }
    [HttpPut("{id:int}")] public async Task<IActionResult> Put(int id, AlumnaEntrada datos, CancellationToken ct)
    { await servicio.EditarAlumnaAsync(id, datos, ct); return NoContent(); }
    [HttpDelete("{id:int}")] public async Task<IActionResult> Delete(int id, CancellationToken ct)
    { await servicio.EliminarAlumnaAsync(id, ct); return NoContent(); }
}
