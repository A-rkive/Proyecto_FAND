using System.Diagnostics;
using Fand.Application;
using Fand.Domain;
using Microsoft.AspNetCore.Mvc;
namespace CLASE_ORM.Middlewares;

// Envuelve el resto del pipeline y traduce fallos a responses JSON consistentes.
public sealed class ErroresMiddleware(RequestDelegate next, ILogger<ErroresMiddleware> logger)
{
    public async Task InvokeAsync(HttpContext context)
    {
        var reloj = Stopwatch.StartNew();
        try { await next(context); }
        catch (OperationCanceledException) when (context.RequestAborted.IsCancellationRequested)
        { context.Response.StatusCode = 499; }
        catch (System.Exception ex) when (!context.Response.HasStarted)
        {
            var status = ex switch
            {
                NoEncontradoException => 404,
                ConflictoException or ReglaNegocioException => 409,
                CredencialesException => 401,
                AccesoDenegadoException => 403,
                _ => 500
            };
            if (status == 500) logger.LogError(ex, "Error no controlado. TraceId {TraceId}", context.TraceIdentifier);
            context.Response.Clear();
            context.Response.StatusCode = status;
            if (status == 401) context.Response.Headers.WWWAuthenticate = "Bearer";
            await context.Response.WriteAsJsonAsync(new ProblemDetails
            {
                Status = status,
                Title = status == 500 ? "Error interno" : "No se pudo completar la operación",
                Detail = status == 500 ? "Ocurrió un error inesperado. Intentá nuevamente." : ex.Message,
                Extensions = { ["traceId"] = context.TraceIdentifier }
            });
        }
        finally
        {
            logger.LogInformation("HTTP {Metodo} {Ruta} → {Estado} en {Tiempo} ms. TraceId {TraceId}",
                context.Request.Method, context.Request.Path, context.Response.StatusCode,
                reloj.ElapsedMilliseconds, context.TraceIdentifier);
        }
    }
}

