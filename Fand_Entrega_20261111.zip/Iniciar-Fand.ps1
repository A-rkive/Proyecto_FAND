$ErrorActionPreference = 'Stop'
$fandRoot = $PSScriptRoot
if (!$env:NUGET_PACKAGES) { $env:NUGET_PACKAGES = Join-Path $env:USERPROFILE '.nuget/packages' }
$fandRuntime = Join-Path $fandRoot '.runtime'
New-Item -ItemType Directory -Force -Path $fandRuntime | Out-Null
$fandProcesses = @()
$fandStatePath = Join-Path $fandRuntime 'procesos.json'
if (Test-Path -LiteralPath $fandStatePath) {
    foreach ($fandSavedProcess in (Get-Content -LiteralPath $fandStatePath -Raw | ConvertFrom-Json)) {
        $fandProcesses += $fandSavedProcess
    }
}
function Test-FandPort([int]$port) {
    try { $null = Invoke-WebRequest -UseBasicParsing -Uri "http://localhost:$port/" -TimeoutSec 2; return $true }
    catch [System.Net.WebException] { return ($null -ne $_.Exception.Response) }
    catch { return $false }
}
if (!(Test-FandPort 5201)) {
    $fandProject = Join-Path $fandRoot 'CLASE_ORM/CLASE_ORM.csproj'
    if (!(Test-Path -LiteralPath (Join-Path $fandRoot 'CLASE_ORM/obj/project.assets.json'))) {
        & dotnet restore $fandProject --disable-parallel -p:NuGetAudit=false
        if ($LASTEXITCODE -ne 0) { throw 'No se pudieron restaurar las dependencias del backend.' }
    }
    & dotnet build $fandProject --no-restore -m:1 -p:UseSharedCompilation=false --nologo -v:quiet
    if ($LASTEXITCODE -ne 0) { throw 'No se pudo compilar el backend.' }
    $api = Start-Process -FilePath 'dotnet.exe' -ArgumentList @('run','--no-build','--launch-profile','http') -WorkingDirectory (Join-Path $fandRoot 'CLASE_ORM') -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $fandRuntime 'api.log') -RedirectStandardError (Join-Path $fandRuntime 'api-error.log')
    $fandProcesses += @{ Id = $api.Id; Inicio = $api.StartTime.ToUniversalTime().ToString('O'); Nombre = 'API' }
}
if (!(Test-FandPort 4200)) {
    if (!(Test-Path -LiteralPath (Join-Path $fandRoot 'TestAngular/node_modules'))) {
        Push-Location (Join-Path $fandRoot 'TestAngular')
        try { & npm.cmd ci --ignore-scripts --no-audit --no-fund; if ($LASTEXITCODE -ne 0) { throw 'No se pudieron instalar las dependencias de Angular.' } }
        finally { Pop-Location }
    }
    $front = Start-Process -FilePath 'cmd.exe' -ArgumentList @('/c','npm.cmd start -- --host localhost') -WorkingDirectory (Join-Path $fandRoot 'TestAngular') -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $fandRuntime 'angular.log') -RedirectStandardError (Join-Path $fandRuntime 'angular-error.log')
    $fandProcesses += @{ Id = $front.Id; Inicio = $front.StartTime.ToUniversalTime().ToString('O'); Nombre = 'Angular' }
}
# Guardar siempre como array, también en Windows PowerShell 5.
ConvertTo-Json -InputObject @($fandProcesses) | Set-Content -LiteralPath $fandStatePath -Encoding UTF8
for ($fandTry = 0; $fandTry -lt 40; $fandTry++) {
    if ((Test-FandPort 5201) -and (Test-FandPort 4200)) { break }
    Start-Sleep -Milliseconds 500
}
if (!(Test-FandPort 5201) -or !(Test-FandPort 4200)) { throw 'Revisar .runtime: algun servicio no pudo iniciar.' }
Write-Host 'Fand disponible en http://localhost:4200'
Start-Process 'http://localhost:4200'

