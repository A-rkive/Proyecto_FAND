using Fand.Domain;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
namespace Fand.Infrastructure.Data;

public static class Inicializador
{
    public static async Task CrearAdminAsync(AppDbContext db, IConfiguration config)
    {
        if (await db.Usuarios.AnyAsync(u => u.Rol == Roles.Admin)) return;
        var email = config["AdminInicial:Email"]?.Trim().ToLowerInvariant();
        var password = config["AdminInicial:Password"];
        if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
            throw new InvalidOperationException("Configurá AdminInicial:Email y AdminInicial:Password mediante User Secrets o variables de entorno.");
        if (await db.Usuarios.AnyAsync(u => u.Email == email))
            throw new InvalidOperationException("El email inicial ya pertenece a otra cuenta.");
        var usuario = new Usuario { Email = email, Rol = Roles.Admin };
        usuario.PasswordHash = new PasswordHasher<Usuario>().HashPassword(usuario, password);
        db.Usuarios.Add(usuario);
        await db.SaveChangesAsync();
    }
}

