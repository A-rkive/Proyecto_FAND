using Fand.Domain;
using Microsoft.EntityFrameworkCore;
namespace Fand.Infrastructure.Data;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<Alumno> Alumnos => Set<Alumno>();
    public DbSet<Materia> Materias => Set<Materia>();
    public DbSet<Profesor> Profesores => Set<Profesor>();
    public DbSet<Usuario> Usuarios => Set<Usuario>();
    public DbSet<Inscripcion> Inscripciones => Set<Inscripcion>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.Entity<Usuario>(u =>
        {
            u.Property(x => x.Email).HasMaxLength(254).IsRequired();
            u.HasIndex(x => x.Email).IsUnique();
            u.Property(x => x.PasswordHash).HasMaxLength(512).IsRequired();
            u.Property(x => x.Rol).HasMaxLength(20).IsRequired();
        });
        modelBuilder.Entity<Alumno>(a =>
        {
            a.Property(x => x.Nombre).HasMaxLength(100).IsRequired();
            a.Property(x => x.Apellido).HasMaxLength(100).IsRequired();
            a.Property(x => x.Email).HasMaxLength(254).IsRequired();
            a.Property(x => x.Domicilio).HasMaxLength(250).IsRequired();
            a.Property(x => x.Telefono).HasMaxLength(25).IsRequired();
            a.Property(x => x.Dni).HasMaxLength(9);
            a.Property(x => x.Legajo).HasMaxLength(30).IsRequired();
            a.HasIndex(x => x.Dni).IsUnique().HasFilter("[Dni] IS NOT NULL");
            a.HasIndex(x => x.Legajo).IsUnique();
            a.ToTable(t => t.HasCheckConstraint("CK_Alumnos_Anio", "[Anio] BETWEEN 1 AND 3"));
        });
        modelBuilder.Entity<Materia>(m =>
        {
            m.Property(x => x.Nombre).HasMaxLength(150).IsRequired();
            m.ToTable(t => t.HasCheckConstraint("CK_Materias_Anio", "[Anio] BETWEEN 1 AND 3"));
        });
        modelBuilder.Entity<Inscripcion>(i =>
        {
            i.HasIndex(x => new { x.AlumnoId, x.MateriaId }).IsUnique();
            i.HasOne(x => x.Alumno).WithMany(x => x.Inscripciones).HasForeignKey(x => x.AlumnoId).OnDelete(DeleteBehavior.Restrict);
            i.HasOne(x => x.Materia).WithMany(x => x.Inscripciones).HasForeignKey(x => x.MateriaId).OnDelete(DeleteBehavior.Restrict);
        });
    }
}

