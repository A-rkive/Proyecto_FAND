using Fand.Application;
using Fand.Domain;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
namespace Fand.Infrastructure.Data;

public sealed class AcademiaRepository(AppDbContext db) : IAcademiaRepository
{
    public async Task<Pagina<AlumnaDto>> ListarAlumnasAsync(FiltroListado f, CancellationToken ct)
    {
        var q = db.Alumnos.AsNoTracking();
        var texto = f.Busqueda?.Trim();
        if (!string.IsNullOrEmpty(texto))
            q = q.Where(a => (a.Nombre + " " + a.Apellido).Contains(texto) ||
                (a.Apellido + " " + a.Nombre).Contains(texto) || a.Email.Contains(texto) ||
                (a.Dni != null && a.Dni.Contains(texto)) || a.Legajo.Contains(texto));
        if (f.Anio.HasValue) q = q.Where(a => a.Anio == f.Anio);
        var total = await q.CountAsync(ct);
        var alumnas = await q.OrderBy(a => a.Apellido).ThenBy(a => a.Nombre).ThenBy(a => a.Id)
            .Skip((f.Pagina - 1) * f.Tamano).Take(f.Tamano)
            .Include(a => a.Inscripciones).ThenInclude(i => i.Materia).AsSplitQuery().ToListAsync(ct);
        return new(alumnas.Select(AcademiaService.Mapear).ToList(), total, f.Pagina, f.Tamano);
    }
    public Task<Alumno?> AlumnaAsync(int id, CancellationToken ct) =>
        db.Alumnos.Include(a => a.Inscripciones).ThenInclude(i => i.Materia).FirstOrDefaultAsync(a => a.Id == id, ct);
    public Task<bool> IdentificacionEnUsoAsync(string dni, string legajo, int excluirId, CancellationToken ct) =>
        db.Alumnos.AnyAsync(a => a.Id != excluirId && (a.Dni == dni || a.Legajo == legajo), ct);
    public void Agregar(Alumno a) => db.Alumnos.Add(a);
    public void Eliminar(Alumno a) => db.Alumnos.Remove(a);

    public async Task<Pagina<MateriaDto>> ListarMateriasAsync(FiltroListado f, CancellationToken ct)
    {
        var q = db.Materias.AsNoTracking();
        var texto = f.Busqueda?.Trim();
        if (!string.IsNullOrEmpty(texto)) q = q.Where(m => m.Nombre.Contains(texto));
        if (f.Anio.HasValue) q = q.Where(m => m.Anio == f.Anio);
        if (f.AnioMax.HasValue) q = q.Where(m => m.Anio <= f.AnioMax);
        var total = await q.CountAsync(ct);
        var items = await q.OrderBy(m => m.Anio).ThenBy(m => m.Nombre).ThenBy(m => m.Id)
            .Skip((f.Pagina - 1) * f.Tamano).Take(f.Tamano)
            .Select(m => new MateriaDto(m.Id, m.Nombre, m.Anio, m.Inscripciones.Count)).ToListAsync(ct);
        return new(items, total, f.Pagina, f.Tamano);
    }
    public Task<Materia?> MateriaAsync(int id, CancellationToken ct) =>
        db.Materias.Include(m => m.Inscripciones).ThenInclude(i => i.Alumno).FirstOrDefaultAsync(m => m.Id == id, ct);
    public Task<bool> MateriaRepetidaAsync(string nombre, int anio, int excluirId, CancellationToken ct) =>
        db.Materias.AnyAsync(m => m.Id != excluirId && m.Nombre == nombre && m.Anio == anio, ct);
    public void Agregar(Materia m) => db.Materias.Add(m);
    public void Eliminar(Materia m) => db.Materias.Remove(m);
    public Task<Inscripcion?> InscripcionAsync(int id, CancellationToken ct) => db.Inscripciones.FirstOrDefaultAsync(i => i.Id == id, ct);
    public void Agregar(Inscripcion i) => db.Inscripciones.Add(i);
    public void Eliminar(Inscripcion i) => db.Inscripciones.Remove(i);
    public async Task GuardarAsync(CancellationToken ct)
    {
        try { await db.SaveChangesAsync(ct); }
        catch (DbUpdateException ex) when (ex.InnerException is SqlException { Number: 2601 or 2627 })
        { throw new ConflictoException("Ya existe un registro con ese DNI, legajo o inscripción. Actualizá el listado e intentá nuevamente."); }
        catch (DbUpdateException ex) when (ex.InnerException is SqlException { Number: 547 })
        { throw new ConflictoException("La operación entra en conflicto con datos relacionados. Revisá las inscripciones y el año de cursada."); }
    }
    public async Task<ResumenDto> ResumenAsync(CancellationToken ct)
    {
        var alumnas = await db.Alumnos.AsNoTracking().GroupBy(a => a.Anio)
            .Select(g => new { Anio = g.Key, Total = g.Count() }).ToListAsync(ct);
        var materias = await db.Materias.AsNoTracking().GroupBy(m => m.Anio)
            .Select(g => new { Anio = g.Key, Total = g.Count() }).ToListAsync(ct);
        var cursos = Enumerable.Range(1, 3).Select(anio => new CursoDto(anio,
            alumnas.FirstOrDefault(a => a.Anio == anio)?.Total ?? 0,
            materias.FirstOrDefault(m => m.Anio == anio)?.Total ?? 0)).ToList();
        return new(alumnas.Sum(a => a.Total), materias.Sum(m => m.Total), await db.Inscripciones.CountAsync(ct), cursos);
    }
}

