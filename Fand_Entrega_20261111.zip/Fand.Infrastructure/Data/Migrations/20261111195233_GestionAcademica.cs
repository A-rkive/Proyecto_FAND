﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Fand.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class GestionAcademica : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Alumnos_Materias_MateriaId",
                table: "Alumnos");

            migrationBuilder.DropIndex(
                name: "IX_Alumnos_MateriaId",
                table: "Alumnos");

            // MateriaId no es un año: primero conservamos la relación en Inscripciones.
            migrationBuilder.AddColumn<int>(
                name: "Anio", table: "Alumnos", type: "int", nullable: false, defaultValue: 1);

            migrationBuilder.AlterColumn<string>(
                name: "Nombre",
                table: "Materias",
                type: "nvarchar(150)",
                maxLength: 150,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<int>(
                name: "Anio",
                table: "Materias",
                type: "int",
                nullable: false,
                defaultValue: 1);

            migrationBuilder.AlterColumn<string>(
                name: "Nombre",
                table: "Alumnos",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "Email",
                table: "Alumnos",
                type: "nvarchar(254)",
                maxLength: 254,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<string>(
                name: "Apellido",
                table: "Alumnos",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Dni",
                table: "Alumnos",
                type: "nvarchar(9)",
                maxLength: 9,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Domicilio",
                table: "Alumnos",
                type: "nvarchar(250)",
                maxLength: 250,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Legajo",
                table: "Alumnos",
                type: "nvarchar(30)",
                maxLength: 30,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Telefono",
                table: "Alumnos",
                type: "nvarchar(25)",
                maxLength: 25,
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateTable(
                name: "Inscripciones",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AlumnoId = table.Column<int>(type: "int", nullable: false),
                    MateriaId = table.Column<int>(type: "int", nullable: false),
                    Fecha = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Inscripciones", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Inscripciones_Alumnos_AlumnoId",
                        column: x => x.AlumnoId,
                        principalTable: "Alumnos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Inscripciones_Materias_MateriaId",
                        column: x => x.MateriaId,
                        principalTable: "Materias",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.Sql("""
                UPDATE Alumnos SET Legajo = CONCAT('FAND-', Id);
                INSERT INTO Inscripciones (AlumnoId, MateriaId, Fecha)
                SELECT Id, MateriaId, SYSUTCDATETIME() FROM Alumnos;
                """);
            migrationBuilder.DropColumn(name: "MateriaId", table: "Alumnos");

            migrationBuilder.AddCheckConstraint(
                name: "CK_Materias_Anio",
                table: "Materias",
                sql: "[Anio] BETWEEN 1 AND 3");

            migrationBuilder.CreateIndex(
                name: "IX_Alumnos_Dni",
                table: "Alumnos",
                column: "Dni",
                unique: true,
                filter: "[Dni] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_Alumnos_Legajo",
                table: "Alumnos",
                column: "Legajo",
                unique: true);

            migrationBuilder.AddCheckConstraint(
                name: "CK_Alumnos_Anio",
                table: "Alumnos",
                sql: "[Anio] BETWEEN 1 AND 3");

            migrationBuilder.CreateIndex(
                name: "IX_Inscripciones_AlumnoId_MateriaId",
                table: "Inscripciones",
                columns: new[] { "AlumnoId", "MateriaId" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Inscripciones_MateriaId",
                table: "Inscripciones",
                column: "MateriaId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // El esquema anterior exige exactamente una materia por alumna.
            migrationBuilder.Sql("""
                IF EXISTS (SELECT a.Id FROM Alumnos a LEFT JOIN Inscripciones i ON a.Id = i.AlumnoId
                           GROUP BY a.Id HAVING COUNT(i.Id) <> 1)
                    THROW 50000, 'No se puede revertir: cada alumna debe tener exactamente una inscripción.', 1;
                """);
            migrationBuilder.AddColumn<int>(name: "MateriaId", table: "Alumnos", type: "int", nullable: false, defaultValue: 0);
            migrationBuilder.Sql("UPDATE a SET MateriaId = i.MateriaId FROM Alumnos a JOIN Inscripciones i ON a.Id = i.AlumnoId;");
            migrationBuilder.DropTable(
                name: "Inscripciones");

            migrationBuilder.DropCheckConstraint(
                name: "CK_Materias_Anio",
                table: "Materias");

            migrationBuilder.DropIndex(
                name: "IX_Alumnos_Dni",
                table: "Alumnos");

            migrationBuilder.DropIndex(
                name: "IX_Alumnos_Legajo",
                table: "Alumnos");

            migrationBuilder.DropCheckConstraint(
                name: "CK_Alumnos_Anio",
                table: "Alumnos");

            migrationBuilder.DropColumn(
                name: "Anio",
                table: "Materias");

            migrationBuilder.DropColumn(
                name: "Apellido",
                table: "Alumnos");

            migrationBuilder.DropColumn(
                name: "Dni",
                table: "Alumnos");

            migrationBuilder.DropColumn(
                name: "Domicilio",
                table: "Alumnos");

            migrationBuilder.DropColumn(
                name: "Legajo",
                table: "Alumnos");

            migrationBuilder.DropColumn(
                name: "Telefono",
                table: "Alumnos");

            migrationBuilder.DropColumn(name: "Anio", table: "Alumnos");

            migrationBuilder.AlterColumn<string>(
                name: "Nombre",
                table: "Materias",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(150)",
                oldMaxLength: 150);

            migrationBuilder.AlterColumn<string>(
                name: "Nombre",
                table: "Alumnos",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100);

            migrationBuilder.AlterColumn<string>(
                name: "Email",
                table: "Alumnos",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(254)",
                oldMaxLength: 254);

            migrationBuilder.CreateIndex(
                name: "IX_Alumnos_MateriaId",
                table: "Alumnos",
                column: "MateriaId");

            migrationBuilder.AddForeignKey(
                name: "FK_Alumnos_Materias_MateriaId",
                table: "Alumnos",
                column: "MateriaId",
                principalTable: "Materias",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
