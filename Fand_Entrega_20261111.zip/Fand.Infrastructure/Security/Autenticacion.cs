using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Fand.Application;
using Fand.Domain;
using Fand.Infrastructure.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
namespace Fand.Infrastructure.Security;

public sealed class UsuarioRepository(AppDbContext db) : IUsuarioRepository
{
    public Task<Usuario?> PorEmailAsync(string email, CancellationToken ct) => db.Usuarios.FirstOrDefaultAsync(u => u.Email == email, ct);
    public Task GuardarAsync(CancellationToken ct) => db.SaveChangesAsync(ct);
}
public sealed class Claves : IClaves
{
    private readonly PasswordHasher<Usuario> hasher = new();
    public bool Verificar(Usuario usuario, string password)
    {
        var resultado = hasher.VerifyHashedPassword(usuario, usuario.PasswordHash, password);
        if (resultado == PasswordVerificationResult.SuccessRehashNeeded)
            usuario.PasswordHash = hasher.HashPassword(usuario, password);
        return resultado != PasswordVerificationResult.Failed;
    }
}
public sealed record JwtSettings(string Key, string Issuer = "Fand.Api", string Audience = "Fand.Angular", int Minutos = 120);
public sealed class TokenService(JwtSettings settings) : ITokenService
{
    public SesionDto Crear(Usuario usuario)
    {
        var expira = DateTime.UtcNow.AddMinutes(settings.Minutos);
        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub, usuario.Id.ToString()),
            new Claim(JwtRegisteredClaimNames.Email, usuario.Email),
            new Claim("role", usuario.Rol),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
        };
        var credenciales = new SigningCredentials(
            new SymmetricSecurityKey(Encoding.UTF8.GetBytes(settings.Key)), SecurityAlgorithms.HmacSha256);
        var token = new JwtSecurityToken(settings.Issuer, settings.Audience, claims,
            notBefore: DateTime.UtcNow, expires: expira, signingCredentials: credenciales);
        return new(new JwtSecurityTokenHandler().WriteToken(token), expira, usuario.Email, usuario.Rol);
    }
}

